# ClocX_Skins  
ClocXの自作着せ替えのレポジトリです｡  
This is the Repository of ClocX presets/skins/watch faces.  

ClocXとは､デスクトップ上にアナログ時計を表示できるWindowsのアプリです｡詳細な情報やDLはWebsiteのリンクを見てください｡  
ClocX is a Software for Windows which made by Bohdan Rylko. For detailed infomation, please visit the link of "Website".  

ファイルはすべてzipファイルにも入っています｡  
All files is in the .zip file.  
ZIPファイルの中身を C:\Program Files\ClocX\Presetsに入れれば使えるようになります｡   
You can use the entire contents of the ZIP file by placing it in C:\Program Files\ClocX\Presets.  

RIGHTS/権利表記  
Creative Commons... CC BY-NC-SA  
The text on the clock face is free fonts.  
時計の文字盤の文字はフリーフォントを使用しています｡  

Thanks to the developer of ClocX (Bohdan Rylko) for making awesome free software! ;)  
